/*
Alex Ye
aye01@calpoly.edu
*/
DROP TABLE `Reservations`;
DROP TABLE `Rooms`;