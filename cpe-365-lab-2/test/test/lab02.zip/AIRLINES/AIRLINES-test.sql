/*
Alex Ye
aye01@calpoly.edu
*/
select * from `airports100`;
select * from `airlines`;
select * from `flights`;