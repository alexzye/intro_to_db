/*
Alex Ye
aye01@calpoly.edu
*/
DROP TABLE `cars-data`;
DROP TABLE `car-names`;
DROP TABLE `model-list`;
DROP TABLE `car-makers`;
DROP TABLE `countries`;
DROP TABLE `continents`;
