/*
Alex Ye
aye01@calpoly.edu
*/
select * from `continents`;
select * from `countries`;
select * from `car-makers`;
select * from `model-list`;
select * from `car-names`;
select * from `cars-data`;