/*
Alex Ye
aye01@calpoly.edu
*/
select * from `Campuses`;
select * from `disciplines`;
select * from `degrees`;
select * from `discipline-enrollments`;
select * from `enrollments`;
select * from `faculty`;
select * from `csu-fees`;