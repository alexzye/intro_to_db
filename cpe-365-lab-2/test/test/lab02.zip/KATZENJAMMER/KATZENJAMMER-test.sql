/*
Alex Ye
aye01@calpoly.edu
*/
select * from `Band`;
select * from `Songs`;
select * from `Albums`;
select * from `Tracklists`;
select * from `Instruments`;
select * from `Performance`;
select * from `Vocals`;