/*
Alex Ye
aye01@calpoly.edu
*/
DROP TABLE `Vocals`;
DROP TABLE `Performance`;
DROP TABLE `Instruments`;
DROP TABLE `Tracklists`;
DROP TABLE `Songs`;
DROP TABLE `Band`;
DROP TABLE `Albums`;
