/*
Alex Ye
aye01@calpoly.edu
*/
DROP TABLE `items`;
DROP TABLE `receipts`;
DROP TABLE `goods`;
DROP TABLE `customers`;