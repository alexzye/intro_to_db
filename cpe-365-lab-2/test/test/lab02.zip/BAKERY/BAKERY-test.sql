/*
Alex Ye
aye01@calpoly.edu
*/
select * from `goods`;
select * from `customers`;
select * from `receipts`;
select * from `items`;