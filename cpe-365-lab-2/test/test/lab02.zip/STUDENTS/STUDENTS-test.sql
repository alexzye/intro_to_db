/*
Alex Ye
aye01@calpoly.edu
*/
select * from `teachers`;
select * from `list`;
