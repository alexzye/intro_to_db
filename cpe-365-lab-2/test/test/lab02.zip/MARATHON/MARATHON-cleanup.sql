/*
Alex Ye
aye01@calpoly.edu
*/
DROP TABLE `marathon`;
