/*
Alex Ye
aye01@calpoly.edu
*/
select * from `marathon`;