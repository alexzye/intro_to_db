/*
Alex Ye
aye01@calpoly.edu
*/
DROP TABLE `wine`;
DROP TABLE `grapes`;
DROP TABLE `appellations`;