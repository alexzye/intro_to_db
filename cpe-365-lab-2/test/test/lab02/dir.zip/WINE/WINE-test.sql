/*
Alex Ye
aye01@calpoly.edu
*/
select * from `grapes`;
select * from `appellations`;
select * from `wine`;