/*
Alex Ye
aye01@calpoly.edu
*/
INSERT INTO `model-list` VALUES(1,1,'amc');
INSERT INTO `model-list` VALUES(2,2,'audi');
INSERT INTO `model-list` VALUES(3,3,'bmw');
INSERT INTO `model-list` VALUES(4,4,'buick');
INSERT INTO `model-list` VALUES(5,4,'cadillac');
INSERT INTO `model-list` VALUES(6,5,'capri');
INSERT INTO `model-list` VALUES(7,4,'chevrolet');
INSERT INTO `model-list` VALUES(8,6,'chrysler');
INSERT INTO `model-list` VALUES(9,7,'citroen');
INSERT INTO `model-list` VALUES(10,8,'datsun');
INSERT INTO `model-list` VALUES(11,6,'dodge');
INSERT INTO `model-list` VALUES(12,9,'fiat');
INSERT INTO `model-list` VALUES(13,5,'ford');
INSERT INTO `model-list` VALUES(14,10,'hi');
INSERT INTO `model-list` VALUES(15,11,'honda');
INSERT INTO `model-list` VALUES(16,12,'mazda');
INSERT INTO `model-list` VALUES(17,13,'mercedes');
INSERT INTO `model-list` VALUES(18,13,'mercedes-benz');
INSERT INTO `model-list` VALUES(19,5,'mercury');
INSERT INTO `model-list` VALUES(20,8,'nissan');
INSERT INTO `model-list` VALUES(21,4,'oldsmobile');
INSERT INTO `model-list` VALUES(22,14,'opel');
INSERT INTO `model-list` VALUES(23,15,'peugeot');
INSERT INTO `model-list` VALUES(24,6,'plymouth');
INSERT INTO `model-list` VALUES(25,4,'pontiac');
INSERT INTO `model-list` VALUES(26,16,'renault');
INSERT INTO `model-list` VALUES(27,17,'saab');
INSERT INTO `model-list` VALUES(28,18,'subaru');
INSERT INTO `model-list` VALUES(29,19,'toyota');
INSERT INTO `model-list` VALUES(30,20,'triumph');
INSERT INTO `model-list` VALUES(31,2,'volkswagen');
INSERT INTO `model-list` VALUES(32,21,'volvo');
INSERT INTO `model-list` VALUES(33,22,'kia');
INSERT INTO `model-list` VALUES(34,23,'hyundai');
INSERT INTO `model-list` VALUES(35,6,'jeep');
INSERT INTO `model-list` VALUES(36,19,'scion');
