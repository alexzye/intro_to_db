/*
Alex Ye
aye01@calpoly.edu
*/
DROP TABLE `faculty`;
DROP TABLE `enrollments`;
DROP TABLE `discipline-enrollments`;
DROP TABLE `disciplines`;
DROP TABLE `degrees`;
DROP TABLE `csu-fees`;
DROP TABLE `Campuses`;
