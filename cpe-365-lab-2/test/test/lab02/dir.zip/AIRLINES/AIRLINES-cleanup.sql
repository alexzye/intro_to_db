/*
Alex Ye
aye01@calpoly.edu
*/
DROP TABLE `flights`;
DROP TABLE `airports100`;
DROP TABLE `airlines`;