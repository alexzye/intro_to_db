DROP TABLE CarsData;
DROP TABLE CarNames;
DROP TABLE Models;
DROP TABLE CarMakers;
DROP TABLE Countries;
DROP TABLE Continents;
