DROP TABLE Faculty;
DROP TABLE Enrollment;
DROP TABLE DiscEnrollment;
DROP TABLE Disciplines;
DROP TABLE Degrees;
DROP TABLE Fees;
DROP TABLE Campuses;

