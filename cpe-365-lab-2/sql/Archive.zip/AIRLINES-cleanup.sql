DROP TABLE Flights;
DROP TABLE Airports;
DROP TABLE Airlines;