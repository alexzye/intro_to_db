DROP TABLE Students;
DROP TABLE Teachers;