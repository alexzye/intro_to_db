DROP TABLE Vocals;
DROP TABLE Performances;
DROP TABLE Instruments;
DROP TABLE Tracklists;
DROP TABLE Songs;
DROP TABLE Band;
DROP TABLE Albums;
